from datetime import datetime

from sqlalchemy import JSON, DateTime, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from backend.database.config import Base


class AiChatModel(Base):
    __tablename__= "chats"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    #user_id: Mapped[int] = mapped_column(Integer)
    thread_id: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())
    
    
class TaskModel(Base):
    __tablename__ = "agent_tasks"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    
    thread_id: Mapped[str] = mapped_column(String(255), index=True)
    
    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[str] = mapped_column(Text)
    
    files: Mapped[list[str]] = mapped_column(JSON, default=list)
    
    reason: Mapped[str] = mapped_column(Text, default="")
    priority: Mapped[str] = mapped_column(String(50), default="medium")
    status: Mapped[str] = mapped_column(String(50), default="pending")

    code_snippet: Mapped[str | None] = mapped_column(Text, nullable=True, default=None)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True, default=None)

    steps: Mapped[list[dict] | None] = mapped_column(JSON, nullable=True, default=None)
    verify: Mapped[list[dict] | None] = mapped_column(JSON, nullable=True, default=None)
    attempts: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
