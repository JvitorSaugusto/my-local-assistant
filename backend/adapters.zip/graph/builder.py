from langgraph.graph import START, END, StateGraph
from langgraph.prebuilt import ToolNode, tools_condition
from .config import State
from .ops_node import ops_node
from .nodes import (
    after_enhancer_route,
    context_gatherer_node,
    enhancer_node,
    generate_dispatch_node,
    heavy_analyzer_node,
    note_draft_node,
    note_refine_node,
    return_tool_message,
    router_node,
    standard_node_20b,
    code_node,
    summarize_node,
    route_decision,
    check_context_limit,
    generate_node,
)

from .tools import append_to_file, create_git_branch, create_new_file, create_pdf_file, edit_existing_file, batch_edit_file, generate_repo_map, list_directory_files, read_file_content, replace_in_file, search_in_file, search_codebase, read_file_chunk, validate_python_syntax, write_markdown_file


def build_graph():
    builder = StateGraph(State)
    
    all_tools = [
        list_directory_files,
        read_file_content,
        read_file_chunk,
        search_in_file,
        search_codebase,
        generate_repo_map,
        create_git_branch,
        create_new_file,
        edit_existing_file,
        batch_edit_file,
        append_to_file,
        replace_in_file,
        write_markdown_file,
        create_pdf_file,
        validate_python_syntax,
    ]

    builder.add_node("tools", ToolNode(all_tools))

    builder.add_node("router_node", router_node)
    
    builder.add_node("standard_node_20b", standard_node_20b)
    builder.add_node("code_node", code_node)
    builder.add_node("generate_node", generate_node)
    builder.add_node("generate_dispatch_node",generate_dispatch_node,)
    builder.add_node("note_draft_node", note_draft_node)
    builder.add_node("note_refine_node", note_refine_node)
    builder.add_node("context_gatherer_node", context_gatherer_node)
    builder.add_node("heavy_analyzer_node", heavy_analyzer_node)
    builder.add_node("summarize_node", summarize_node)
    builder.add_node("ops_node", ops_node)
    builder.add_node("enhancer_node", enhancer_node)
    
    builder.add_conditional_edges(
        START,
            check_context_limit,
            {
                "go_to_summarize":"summarize_node",
                "go_to_router":"router_node"
            }
        )    

    builder.add_edge("summarize_node", "router_node")

    builder.add_conditional_edges(
        "router_node",
        route_decision,
        {
            "standard_node_20b": "standard_node_20b",
            "code_node": "code_node",
            "generate_node": "generate_node",
            "generate_dispatch_node": "generate_dispatch_node",
            "note_draft_node": "note_draft_node",
            "heavy_analyzer_node": "heavy_analyzer_node",
            "context_gatherer_node": "context_gatherer_node",
            "ops_node": "ops_node",
            "enhancer_node": "enhancer_node",
        }
    )
    
    builder.add_conditional_edges(
        "enhancer_node",
        after_enhancer_route,
        {
            "context_gatherer_node": "context_gatherer_node",
            "router_node": "router_node",
        },
    )
    
    builder.add_conditional_edges(
        "note_draft_node",
        tools_condition,
            {
                "tools": "tools",
                "__end__": "note_refine_node",
            }
        )
    
    builder.add_conditional_edges(
    "code_node",
    tools_condition,
        {
            "tools": "tools",
            "__end__": END,
        }
    )
    
    builder.add_conditional_edges(
        "generate_node",
        tools_condition,
            {
                "tools": "tools",
                "__end__": END,
            }
        )
    
    builder.add_conditional_edges(
        "generate_dispatch_node",
        tools_condition,
            {
                "tools": "tools",
                "__end__": END,
            }
        )

    builder.add_conditional_edges(
        "context_gatherer_node",
        tools_condition, 
        {
            "tools": "tools", 
            "__end__": "heavy_analyzer_node"
        }
    )
    
    builder.add_conditional_edges(
        "tools", 
        return_tool_message, 
        {
            "code_node": "code_node",
            "generate_node": "generate_node",
            "generate_dispatch_node": "generate_dispatch_node",
            "note_draft_node": "note_draft_node", 
            "context_gatherer_node": "context_gatherer_node"
        }
    )
    
    builder.add_edge("heavy_analyzer_node", END)
    builder.add_edge("ops_node", END)

    builder.add_edge("note_refine_node", END)
    builder.add_edge("standard_node_20b", END)
    

    return builder


def compile_graph():
    return build_graph().compile()
    